package gestion_restau;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Commande {
	private ArrayList<Ligne_comm> c=new ArrayList<Ligne_comm>();
	private int n_tab;
	private int code;
	private LocalDate date;
	private LocalTime time;
	private String modepay;
	private boolean cloture;
	private Serveur serveur;

	public Commande(ArrayList<Ligne_comm> c, int n_tab, LocalDate date, LocalTime time, String modepay, int code,Serveur serveur) {
		 
		this.c = c;
		this.n_tab = n_tab;
		this.date = date;
		this.time = time;
		this.modepay = modepay;
		this.code = code;
		this.cloture = false;
		this.serveur=serveur;
	}

	public double montant() {
		double sum = 0;
		for (int i = 0; i < c.size(); i++) {
			sum =sum + c.get(i).getQuantity() * c.get(i).getP().getPrix();
		}
		return sum;
	}

	public ArrayList<Ligne_comm> getC() {
		return c;
	}

	public void setC(ArrayList<Ligne_comm> c) {
		this.c = c;
	}

	public int getN_tab() {
		return n_tab;
	}

	public void setN_tab(int n_tab) {
		this.n_tab = n_tab;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public String getModepay() {
		return modepay;
	}

	public void setModepay(String modepay) {
		this.modepay = modepay;
	}

	public boolean isCloture() {
		return cloture;
	}

	public void setCloture(boolean cloture) {
		this.cloture = cloture;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String afficher_list_lignecomm() {
		String list = "";
		for (int i = 0; i <= c.size()-1; i++) {
			list = list + ("ligne commande n" + i + c.get(i).toString());
		}
		return list;
	}

	@Override
	public String toString() {
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String formattedDate = date.format(myFormatObj);
		DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("HH:mm:ss");
		String formattedTime = time.format(myFormat);
		String s=("code de la commande " + this.code + "date :le " + formattedDate 
				+ "temps :" + formattedTime+ " numero de la table =" + n_tab
				+" mode de paiement=" + modepay +  "Les ligne commande " + afficher_list_lignecomm());
		if(cloture)
			return s+"cette commande est cloture";
		else 
			return s+"cette commande n'est pas encore cloture";
	}

	

}
