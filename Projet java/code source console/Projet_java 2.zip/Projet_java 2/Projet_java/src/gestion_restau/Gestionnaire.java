package gestion_restau;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Gestionnaire {
	private ArrayList<Plat> liste_plat=new ArrayList<Plat>();
	private ArrayList<Commande> liste_com=new ArrayList<Commande>();
	private ArrayList<Table> liste_table=new ArrayList<Table>();
	private ArrayList<Serveur>Liste_serveurs=new ArrayList<Serveur>();
	private  Scanner sc =new Scanner(System.in);
	private int code=1;
	
	


	
	
	//methode de recherche
	
	public Plat rech_plat(String ref) {
        for (int i = 0; i < liste_plat.size(); i++) {
            if (liste_plat.get(i).getCode_alpha().equals(ref))
                return liste_plat.get(i);

        }
        return null;
	}
	//------------------------------------
	
	public Table rech_table(int n) {
		for (int i = 0; i < liste_table.size(); i++) {
			if (liste_table.get(i).getNumber()==n)
				return liste_table.get(i);
		}
		return null;
	}
	
	//------------------------------------------
	
	
	public Serveur rech_serveur(String id) {
		
		
	    for (int i = 0; i < Liste_serveurs.size(); i++) 
	        if (Liste_serveurs.get(i).getId().equalsIgnoreCase(id))
	            return Liste_serveurs.get(i);

	    
	    
	    return null;
	    }
	
	//---------------------------------------------
	
	
	public Commande rech_com(int ref) {
        for (int i = 0; i < liste_com.size(); i++) {
            if (liste_com.get(i).getCode()==ref)
                return liste_com.get(i);

        }
        return null;

    }
	
	//-------------------------------------------------
	
	// methode de d'ajout
	
	 
		public void ajout_plat(){
			
		System.out.println("donner le code \n");
	    String code = sc.next();
		if(rech_plat(code)!=null)
		System.out.println("le code exisite deja  \n");
		else 
		liste_plat.add(new Plat(code)) ;
		}
	//-----------------------------------------------
		
		
	
		 public Ligne_comm ajout_ligneco() {
	    	 
	    	 String code;
	    	 do {
	 		System.out.println("donner le code du plat \n");
	 		 code = sc.next();
	    	 }while(rech_plat(code)==null);
	        System.out.println("donner la quantite voulue : \n");
	 		int q = sc.nextInt();
	 		rech_plat(code).setQuantitycommand(rech_plat(code).getQuantitycommand()+q);    
	 		Ligne_comm l =new Ligne_comm(rech_plat(code), q);
	 		return l;
	 		
	     }
		 
   //-------------------------------------------------

	     public void ajout_table() {
	    	
	    	 System.out.print("donner le nombre de tables a ajouter \n ");
	    	 int n= sc.nextInt();
	    	 if(rech_table(n)!=null)
	    		 System.out.println("la table existe deja \n ");
	    	 else 
	    		liste_table.add(new Table(n));
	         }
	     
	     
	//----------------------------------------------------
	     
	     public void cree_commande() {
	 		int choix;
	 		ArrayList<Ligne_comm>  c =new ArrayList<Ligne_comm>();
	 		
	 		do {
	 		System.out.println(" commander votre plat \n ");
	 		c.add(ajout_ligneco());
	 		
	 		System.out.println("Voulez vous commander un autre plat 1:oui 0:non \n");
	         choix=sc.nextInt();
	       }while(choix==1);
	 		
	 		int t=reserve_table().getNumber();
	 		
	 		LocalDate date=LocalDate.now();
	 		LocalTime time=LocalTime.now();
	 		String mode;
	 		do {
	 		System.out.println("mode de paiement : \n ");
	 		 mode = sc.next();
	 		}while(!(mode.equalsIgnoreCase("espece") ||mode.equalsIgnoreCase("cheque") ||mode.equalsIgnoreCase("carte bancaire")));
	 		System.out.println("donner l'id de serveur");
	 		String id =sc.next();
	 		
	 	 
	 	if (rech_serveur(id).equals(null))
	 	System.out.println("ce serveur n'existe pas ");
	 	
	 		else
	 		{
	 	    
	 	System.out.println("serveur reserve avec succes ");
	 	
	 		liste_com.add(new Commande(c, t, date, time, mode, t, rech_serveur(id)));
	 		int n = rech_serveur(id).getNb_table_servies()+1;
	 		rech_serveur(id).setNb_table_servies(n);
	 		System.out.println("commande ajoute ! \n");
	 		this.code++;
	 		}
	 		}
	     
	 	
	 //--------------------------------------------------------------
	 	
	     public void add_serveur(){
	    	 
	    	 
	    		System.out.println("donner l'id de le nouveu serveur");
	    		String id =sc.next();
	    		if(rech_serveur(id)!=null)
	    			System.out.println("le serveur deja travaille la ! ");
	    		else 
	    		{
	    			Liste_serveurs.add(new Serveur(id));
	    			System.out.println("serveur ajoute avec succes ");
	    		}
	    		
	    	    }
	  //---------------------------------------------------------------
	     
	 // methode de nodification
	
	public void Modif_plat() {
		
		System.out.println("donner code de plat ");
	     String code =sc.next();
	     int choix=0;
	     if(rech_plat(code)==null)
	     System.out.println("le plat n'existe pas ");
	     else 
	    {
	     Plat p =rech_plat(code);
	     do
	    {
	    System.out.println("donner votre choix \n 1: pour modifier le nom \n 2:pour modifier le prix \n 0:pour quitter ");
	    choix=sc.nextInt();
	     switch(choix) {
	    case 1 :
	     System.out.println("donner le nouveau nom \n");
	     String nom =sc.next();
	     p.setNom_de_plat(nom);;
	     break;
	    case 2:
	    System.out.println("donner le nouveau prix \n");
	    double prix=sc.nextDouble();
	    p.setPrix(prix);;
	    break;
	    		 }	 
	    	 }while(choix!=0);}
	    			
	         }
	
	//-------------------------------------------------------------------------------------------
	
	// methode d'affichage 
	
	
	
	public String aff_plat_ord() {
		Collections.sort(liste_plat);
		Scanner sc =new Scanner(System.in);
		String categorie;
		do
		{
			System.out.println("donner la categorie \n");
			categorie =sc.next();	
		}while(!(categorie.equalsIgnoreCase("dessert") ||categorie.equalsIgnoreCase("suite") ||categorie.equalsIgnoreCase("entree")));
		String s=null;
		for(int i=0;i<liste_plat.size();i++)
			if(liste_plat.get(i).getCategorie().equals(categorie))
				s=s+liste_plat.get(i).toString();
		
		return s;
         }
//------------------------------------------------------------------------------------------------
	
	public String Afficher_commande() {
		System.out.println("donner le code de la commande \n");
		int code =sc.nextInt();
		if(rech_com(code)!=null)
			return rech_com(code).toString();
			else 
		   return "la commande n'existe pas \n ";	
		}
	
	

    
//----------------------------------------------------------------------------------------------------	
	
	 
	/*public void affichage_trier() {
		Collections.sort(liste_plat,Plat.Comparatorcode);  
		Collections.sort(liste_plat, Plat.Comparatorcategorie);
		
		  System.out.println("Afficher Liste des plats par \r\n"
		  		+ "cat�gorie et ordonn�e par R�f�rence");
		  for(Plat e:liste_plat)
		   System.out.println(e);
		  
		  
	}*/
	

	
 // methode de recette 
	
	
	public void recette_journaliaire()
	{

	LocalDate d=LocalDate.now();
	double montant=0.0;
	for(int i=0;i<this.liste_com.size();i++)
	{
	if(this.liste_com.get(i).getDate().isEqual(d))
	{

	montant=montant+this.liste_com.get(i).montant();
	}
	}
	System.out.println("La recette journaliaire est = "+montant);

	}
	
	public double recette_parjour(LocalDate d)	{

	
	double montant=0.0;
	for(int i=0;i<this.liste_com.size();i++)
	{
		if(!liste_com.get(i).isCloture()) {
	if(this.liste_com.get(i).getDate().isEqual(d))
	{

	montant=montant+this.liste_com.get(i).montant();
	}
	}
		}
	return  montant;

	}
	
	
	//----------------------------------------------------------------------------------
	
	public void aff_rec_periode() {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("donner la date de debut \n");
		String s=sc.next();
		DateTimeFormatter myFormatObj =  DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate t1=LocalDate.parse(s,myFormatObj);
		System.out.println("donner la date de fin \n");
		String s1=sc.next();
		LocalDate t2=LocalDate.parse(s1,myFormatObj);
		double montant=0.0;
		while(t1.isBefore(t2)){
			System.out.println("La recette journaliaire de "+t1+"  est  "+recette_parjour(t1));
			montant=montant+recette_parjour(t1);
			t1=t1.plusDays(1);
		}
		System.out.println("le chiffre d'affaire de cette periode est :"+montant);
    	}
	//--------------------------------------------------------------------------
			public String pluscommander() {
				Plat max=null;
				for(int i=0;i<this.liste_plat.size()-1;i++) {
					if(liste_plat.get(i).getQuantitycommand()>liste_plat.get(i+1).getQuantitycommand()) {
						max=liste_plat.get(i);			
					}else	
					  max=liste_plat.get(i+1);	
				     }
				return max.toString();
			       }
			
	//-------------------------------------------------------------------------------------
			public double profit_pur_mois() {
		    	 System.out.println("donner le numero de moins" );
		    	 int s=sc.nextInt();
		    	 System.out.println("donner l'annee" );
		    	 String v=sc.next();
		    	 String ss;
		    	 if(s==10 ||s==11 ||s==12)
		    	  ss="s";
		    	 else
		    		ss="0"+s; 
		    	 String t="01-"+ss+"-"+v;
		 		DateTimeFormatter myFormatObj =  DateTimeFormatter.ofPattern("dd-MM-yyyy");
		 		LocalDate t1=LocalDate.parse(t,myFormatObj);
		 		
		 		double montant=0.0;
		 	    if(s==9 ||s==11 ||s==4||s==6)
		 	    {
		 	    	for(int j=0 ; j<liste_com.size();j++) {
		 	    		if(liste_com.get(j).getDate().getMonthValue()==s) {
		 		for(int i=0 ; i<31;i++) {
		 		montant = montant	+ recette_parjour(t1);
		 		t1.plusDays(1);
		 			
		 		}}}
		 	    }else {if(s==1 ||s==3 ||s==5||s==7||s==8||s==10||s==12)
		 	    {
		 	    	for(int j=0 ; j<liste_com.size();j++) {
		 	    		if(liste_com.get(j).getDate().getMonthValue()==s) {
		 		for(int i=0 ; i<32;i++) {
		 		montant = montant	+ recette_parjour(t1);
		 		t1.plusDays(1);
		 			
		 		}}}
		 	    }else {

		 	    	for(int j=0 ; j<liste_com.size();j++) {
		 	    		if(liste_com.get(j).getDate().getMonthValue()==s) {
		 		for(int i=0 ; i<29;i++) {
		 		montant = montant	+ recette_parjour(t1);
		 		t1.plusDays(1);
		 	    }
		 	    		}}}
		 		for(int i=0 ; i<Liste_serveurs.size();i++) {
		 			
		 			montant =montant-Liste_serveurs.get(i).getSalaire();
		 		}
		 		
		     }
	    	    return montant;
}
			
			
			
			
//------------------------------------------------------------------------
			
			// autre commande 
		     
	
	
	
    
      public Table reserve_table() {
    	  
    	  int n;
    	  LocalTime t=LocalTime.now();
    	  do {
    			System.out.println("donner le numero de la table\n ");
    			 n = sc.nextInt();
    			}while(rech_table(n)==null);
    			if(rech_table(n).isReserve()) {
    			System.out.println("cette table est deja reserve ! veuillez verifier \n ");
    			do {
    			System.out.println("donner une autre table disponible \n ");
    			 n = sc.nextInt();
    				}while(rech_table(n).isReserve());
    				rech_table(n).setReserve(false);
    				  rech_table(n).setT(t);
    				return rech_table(n);}
    			  else {
    			  rech_table(n).setReserve(false);
    			  rech_table(n).setT(t);;
    			
    			return rech_table(n);}
      }
     
	

	
	
      //--------------------------------------------------------
      
      
	public void cloturer_commande() {
		
		System.out.println("donner le code de la commande \n  ");
		int code =sc.nextInt();
		rech_com(code).setCloture(true);
		rech_table(rech_com(code).getN_tab()).setReserve(false);
		System.out.println("commande colture! \n");
		
		
	}
	
	
	//--------------------------------------------------------------- 
	
	
	
	public String best_Serveur(){
		Serveur max = null;
		for (int i=0 ;i<Liste_serveurs.size()-1;i++) {
			if(Liste_serveurs.get(i).getNb_table_servies()<Liste_serveurs.get(i+1).getNb_table_servies())
				max= Liste_serveurs.get(i);	
		}
		return max.toString();	
	}
	public void bonus_salaire() {
		
		for(int i=0 ; i<Liste_serveurs.size();i++)
		{
			int n=20;
			while(n<Liste_serveurs.get(i).getNb_table_servies())
			{
		       
				Liste_serveurs.get(i).setSalaire(Liste_serveurs.get(i).getSalaire()+10.250);
				n++;
				
	      }
		}	
	    }
	
	

//------------------------------------------------------------------------------------



    

public void rush_hour(){
	int frequence,  compteur = 0 ;
	frequence = 0;
	Table valeur=null;
	
		for (int i=0; i < liste_table.size(); i++){
	
			for (int j = 0 ; j < liste_table.size(); j++){
			 if ( liste_table.get(i).getT().getHour() ==liste_table.get(i).getT().getHour() ) {
			compteur = compteur + 1 ;
			}
			}
			if  (compteur > frequence) {
			frequence = compteur ;
			 valeur = liste_table.get(i) ;
			}
	        }
		System.out.println("l'heure le plus charge de jour  est "+valeur.getT().getHour());
	

		
}
}
 	
	

