package gestion_restau;

public class Ligne_comm {
    private Plat p;
	private int quantity;
    
    public Plat getP() {
		return p;
	}
	public void setP(Plat p) {
		this.p = p;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Ligne_commande [nom du plats =" + p + ", quantite=" + quantity + "]";
	}
	
	public Ligne_comm(Plat p, int quantity) {
		this.p = p;
		this.quantity = quantity;
	}
	
	
	
}
