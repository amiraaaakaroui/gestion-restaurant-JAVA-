package gestion_restau;

import java.time.LocalDate;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int choix=0;
	
         Gestionnaire a =new Gestionnaire();
         
         
         System.out.println("***bienvenue dans le restaurant yammy food*** ");
         do {
        	 
         
         System.out.println("taper un numero selon ton besoin  "
         		+ " \n 1:ajouter un plat   \n "
         		+ "2:ajouter_serveur \n "
         		+ "3:ajouter_table \n "
         		+ "4:reserver_table  \n "
         		+ "5:creer commande \n "
         		+ "6:modifier plat \n"
         		+ "7: cloturer une commande \n "
         		+ "8:afficher_une _commande  \n "
         		+ "9:afficher_recette_journaliere \n "
         		+ "10:afficher recette par jour \n "
         		+ "11: afficher recette par periode \n"
         		+ "12: afficher profits pur par moins\n"
         		+ "13: Afficher Liste des plats par cat�gorie et ordonn�e par R�f�rence \n"
         		+ "14: afficher  bonus  serveur \n"
         		+ "15: pour afficher le meilleure serveur \n "
         		+ "16: pour afficher le plat le plus commamde \n"
         		+ "17: rush hour \n"
         		+ "0 :pour quitter");
              choix=  sc.nextInt();
              switch (choix) {
			case 1:a.ajout_plat();
				break;
			case 2:a.add_serveur();
                break;
			case 3:a.ajout_table();
			     break;
			case 4: a.reserve_table();
			break;
			case 5 :a.cree_commande();
			     break;
			case 6 :a.Modif_plat();
			      break;
			case 7 : a.cloturer_commande();
			      break;
			case 8: System.out.println(a.Afficher_commande());
			       break;
			case 9 : a.recette_journaliaire();
				break;
			case 10 : System.out.println("donner le jour pour avoir la recette ");
			LocalDate d=LocalDate.now();
				a.recette_parjour(d)	;
				break;
			case 11 : a.aff_rec_periode();
			     break;
			case 12 : System.out.println(a.profit_pur_mois());
			     break;
			 case 13 : System.out.println(a.aff_plat_ord());
			    break;
			 case 14 : a.bonus_salaire();
			     break;
			 case 15  : System.out.println(a.best_Serveur());
			    break;
			 case 16 : System.out.println(a.pluscommander());
			 break;
			 case 17 : a.rush_hour();
			 break;
			 
			 
			
			 
			     
			
				
			 
			}
         }
              while(choix!=0);
         
	}
       
	

}
