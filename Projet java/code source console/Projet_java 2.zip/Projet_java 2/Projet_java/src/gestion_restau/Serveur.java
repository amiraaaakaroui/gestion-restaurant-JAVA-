package gestion_restau;

import java.util.Scanner;

public class Serveur {
	private String id ;
	private String nom;
	private double Salaire;
	private int nb_table_servies;
	
	
	
	
	

	public Serveur(String id) {
		Scanner sc =new Scanner(System.in);
		this.id = id;
		System.out.println("donner le nom de serveur");
		this.nom =sc.next() ;
		System.out.println("donner le salaire");
		this.Salaire =sc.nextDouble();
		this.nb_table_servies = 0;
	}
	@Override
	public String toString() {
		return "Serveur [id=" + id + ", nom=" + nom + ", Salaire=" + Salaire + ", nb_table_servies=" + nb_table_servies
				+ "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public double getSalaire() {
		return Salaire;
	}
	public void setSalaire(double salaire) {
		Salaire = salaire;
	}
	public int getNb_table_servies() {
		return this.nb_table_servies;
		
		
		
	}
	public void setNb_table_servies(int nb_table_servies) {
		this.nb_table_servies = nb_table_servies;
	}

}
