package gestion_restau;

import java.time.LocalTime;
import java.util.ArrayList;

public class Table {
    @Override
	public String toString() {
		return "Table [number=" + number + ", reserve=" + reserve + ", T=" + T + "]";
	}
	private int number;
    private boolean reserve ;
    private LocalTime T;
    
    
    public LocalTime getT() {
		return T;
	}
	public void setT(LocalTime t) {
		this.T = t;
	}
	
     
    
	public Table(int number) {
		this.number = number;
		this.reserve = false;
		this.T=T;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public boolean isReserve() {
		return reserve;
	}
	public void setReserve(boolean reserve) {
		this.reserve = reserve;
	}
	
    
    
    
}
